namespace HealthFacility_OCP
{
    public enum SpecialtyType
    {
        Cardiology,
        Dermatology,
        Endocrinology,
        Gastroenterology,
        Hematology,
        InfectiousDisease,
        Nephrology,
        Neurology,
        ObstetricsAndGynecology,
        Oncology
    }
}