namespace HealthFacility_ISP 
{
    public interface IClinicNumberSystem_ISP
    {
        public void TakeANumber();
    }
}