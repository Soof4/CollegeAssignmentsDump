
public class Urun_2215 {
	public String Adi;
	public int KategoriIndex;
	public String BirimAgirligi;
	public double BirimFiyati;
	public int StokMiktari;
	
	public Urun_2215(String adi, int kategoriIndex, String birimAgirligi, double birimFiyati, int stokMiktari) {
		this.Adi = adi;
		this.KategoriIndex = kategoriIndex;
		this.BirimAgirligi = birimAgirligi;
		this.BirimFiyati = birimFiyati;
		this.StokMiktari = stokMiktari;
	}
}
