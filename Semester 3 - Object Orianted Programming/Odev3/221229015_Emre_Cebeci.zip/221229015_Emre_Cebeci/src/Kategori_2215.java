
public class Kategori_2215 {
    public int Index;
    public String Adi;
    public String Detay;
    public int Adet;
    
    public Kategori_2215(int index, String adi, String detay, int adet) {
        this.Index = index;
        this.Adi = adi;
        this.Detay = detay;
        this.Adet = adet;
    }
}
